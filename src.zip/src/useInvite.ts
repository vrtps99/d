import { useEffect, useState } from "react";

export type InviteInfo = {
  name: string;
  description: string | null;
  icon: string | null;
  online: number | null;
  members: number | null;
};

// Достаёт код из "https://discord.gg/code", "discord.com/invite/code" или просто "code"
export function parseInvite(input: string): string {
  const clean = input.trim().replace(/[?#].*$/, "").replace(/\/+$/, "");
  return clean.split("/").pop() || clean;
}

export function inviteUrl(input: string): string {
  return `https://discord.gg/${parseInvite(input)}`;
}

const cache = new Map<string, Promise<InviteInfo | null>>();

function load(code: string): Promise<InviteInfo | null> {
  let p = cache.get(code);
  if (!p) {
    p = fetch(`https://discord.com/api/v10/invites/${encodeURIComponent(code)}?with_counts=true`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!d || !d.guild) return null;
        const g = d.guild;
        let icon: string | null = null;
        if (g.icon) {
          const ext = String(g.icon).startsWith("a_") ? "gif" : "png";
          icon = `https://cdn.discordapp.com/icons/${g.id}/${g.icon}.${ext}?size=256`;
        }
        return {
          name: g.name as string,
          description: (g.description as string | null) ?? null,
          icon,
          online: typeof d.approximate_presence_count === "number" ? d.approximate_presence_count : null,
          members: typeof d.approximate_member_count === "number" ? d.approximate_member_count : null,
        };
      })
      .catch(() => null);
    cache.set(code, p);
  }
  return p;
}

export function useInvite(input: string) {
  const code = parseInvite(input);
  const [state, setState] = useState<{ code: string; info: InviteInfo | null; done: boolean }>({
    code,
    info: null,
    done: false,
  });

  useEffect(() => {
    if (!code) return;
    let alive = true;
    load(code).then((info) => {
      if (alive) setState({ code, info, done: true });
    });
    return () => {
      alive = false;
    };
  }, [code]);

  if (!code) return { code, info: null, done: true };
  return state.code === code ? state : { code, info: null, done: false };
}
