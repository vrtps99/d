import type { SocialType } from "./config";

type P = { className?: string };

const base = { viewBox: "0 0 24 24", fill: "currentColor" } as const;

export function SocialIcon({ type, className = "h-5 w-5" }: { type: SocialType } & P) {
  switch (type) {
    case "tiktok":
      return (
        <svg {...base} className={className}>
          <path d="M16.6 3c.3 2.4 1.7 3.9 4 4.1v3c-1.4.1-2.7-.3-4-1.1v6.1c0 3.9-2.7 6-5.7 6-3.1 0-5.6-2.4-5.6-5.5 0-3.4 2.9-5.9 6.3-5.4v3.1c-1.7-.5-3.3.6-3.3 2.3 0 1.4 1.1 2.5 2.5 2.5 1.600 0 2.600-1 2.600-2.800V3h3.200z" />
        </svg>
      );
    case "youtube":
      return (
        <svg {...base} className={className}>
          <path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.200 5 12 5 12 5s-6.200 0-7.800.4A2.500 2.500 0 0 0 2.400 7.200C2 8.800 2 12 2 12s0 3.200.4 4.800a2.500 2.500 0 0 0 1.800 1.800C5.800 19 12 19 12 19s6.200 0 7.800-.4a2.500 2.500 0 0 0 1.800-1.800c.4-1.600.4-4.800.4-4.800s0-3.200-.4-4.800zM10 15V9l5.200 3L10 15z" />
        </svg>
      );
    case "telegram":
      return (
        <svg {...base} className={className}>
          <path d="M21.500 3.300 2.700 10.600c-1.300.5-1.300 1.200-.2 1.500l4.800 1.500 1.800 5.600c.2.600.1.800.7.800.5 0 .7-.2 1-.5l2.300-2.300 4.800 3.500c.9.500 1.500.2 1.700-.8L22.900 4.800c.3-1.200-.5-1.800-1.400-1.500zM8.200 13.200l9.300-5.900c.4-.3.8-.1.500.2l-7.600 6.900-.3 3.200-1.900-4.400z" />
        </svg>
      );
    case "discord":
      return (
        <svg {...base} className={className}>
          <path d="M19.300 5.300A17 17 0 0 0 15.100 4l-.5 1a15.800 15.800 0 0 0-5.200 0l-.5-1a17 17 0 0 0-4.200 1.300C2 9.300 1.300 13.200 1.600 17a17 17 0 0 0 5.200 2.600l1.100-1.800c-.6-.2-1.200-.5-1.700-.9l.4-.3a12 12 0 0 0 10.200 0l.4.300c-.5.400-1.100.7-1.700.9l1.100 1.800a17 17 0 0 0 5.200-2.600c.4-4.400-.7-8.300-3.100-11.700zM8.700 14.700c-1 0-1.800-.9-1.800-2s.8-2 1.800-2 1.800.9 1.800 2-.8 2-1.800 2zm6.600 0c-1 0-1.800-.9-1.800-2s.8-2 1.800-2 1.800.9 1.800 2-.8 2-1.800 2z" />
        </svg>
      );
    case "twitch":
      return (
        <svg {...base} className={className}>
          <path d="M4 3 3 6.500V19h4v2h2.500l2-2H15l5-5V3H4zm14.500 10-3 3H12l-2 2v-2H6.500V5h12v8zM15 8h1.500v4H15V8zm-4 0h1.500v4H11V8z" />
        </svg>
      );
    case "instagram":
      return (
        <svg {...base} className={className}>
          <path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7zm5 3.500a4.500 4.500 0 1 1 0 9 4.500 4.500 0 0 1 0-9zm0 2a2.500 2.500 0 1 0 0 5 2.500 2.500 0 0 0 0-5zM17.500 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
        </svg>
      );
    case "github":
      return (
        <svg {...base} className={className}>
          <path d="M12 2a10 10 0 0 0-3.200 19.500c.5.100.7-.2.7-.5v-1.800c-2.800.6-3.400-1.200-3.400-1.200-.5-1.200-1.100-1.500-1.100-1.500-.9-.6.100-.6.100-.6 1 .1 1.500 1 1.500 1 .9 1.500 2.400 1.100 3 .8.100-.7.400-1.100.7-1.400-2.200-.3-4.600-1.100-4.600-5 0-1.100.4-2 1-2.700-.1-.3-.4-1.300.1-2.700 0 0 .8-.3 2.800 1a9.600 9.600 0 0 1 5 0c1.900-1.300 2.800-1 2.800-1 .5 1.400.2 2.400.1 2.700.6.700 1 1.600 1 2.700 0 3.900-2.400 4.700-4.600 5 .4.300.7.900.7 1.800V21c0 .3.200.6.700.5A10 10 0 0 0 12 2z" />
        </svg>
      );
  }
}

export function DiscordLogo({ className = "h-8 w-8" }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="white" className={className}>
      <path d="M19.300 5.300A17 17 0 0 0 15.100 4l-.5 1a15.800 15.800 0 0 0-5.200 0l-.5-1a17 17 0 0 0-4.200 1.300C2 9.300 1.300 13.200 1.600 17a17 17 0 0 0 5.200 2.600l1.100-1.800c-.6-.2-1.200-.5-1.700-.9l.4-.3a12 12 0 0 0 10.200 0l.4.300c-.5.400-1.100.7-1.700.9l1.100 1.800a17 17 0 0 0 5.200-2.600c.4-4.400-.7-8.300-3.100-11.700zM8.700 14.700c-1 0-1.800-.9-1.800-2s.8-2 1.800-2 1.800.9 1.800 2-.8 2-1.800 2zm6.600 0c-1 0-1.800-.9-1.800-2s.8-2 1.800-2 1.800.9 1.800 2-.8 2-1.800 2z" />
    </svg>
  );
}

export function CreeperLogo({ className = "h-8 w-8" }: P) {
  const d = "#0b2a3a";
  return (
    <svg viewBox="0 0 8 8" className={className} shapeRendering="crispEdges">
      <rect x="1" y="2" width="2" height="2" fill={d} />
      <rect x="5" y="2" width="2" height="2" fill={d} />
      <rect x="3" y="4" width="2" height="2" fill={d} />
      <rect x="2" y="5" width="1" height="2" fill={d} />
      <rect x="5" y="5" width="1" height="2" fill={d} />
    </svg>
  );
}

export function ArrowIcon({ className = "h-3.5 w-3.5" }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M7 17 17 7M8 7h9v9" />
    </svg>
  );
}
