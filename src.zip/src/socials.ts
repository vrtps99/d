import type { SocialType } from "./config";

const NAMES: Record<SocialType, string> = {
  tiktok: "TikTok",
  youtube: "YouTube",
  telegram: "Telegram",
  discord: "Discord",
  twitch: "Twitch",
  instagram: "Instagram",
  github: "GitHub",
};

export type ParsedSocial = {
  type: SocialType | null;
  name: string;
  handle: string;
  href: string;
  // код приглашения Discord (если ссылка на сервер) — по нему подтягивается название
  inviteCode: string;
};

function toUrl(input: string): URL | null {
  const s = input.trim();
  if (!s) return null;
  try {
    return new URL(/^https?:\/\//i.test(s) ? s : `https://${s}`);
  } catch {
    return null;
  }
}

export function detectType(host: string): SocialType | null {
  const h = host.replace(/^www\.|^m\./, "").toLowerCase();
  if (h.endsWith("tiktok.com")) return "tiktok";
  if (h.endsWith("youtube.com") || h === "youtu.be") return "youtube";
  if (h === "t.me" || h.endsWith("telegram.me") || h.endsWith("telegram.org")) return "telegram";
  if (h.endsWith("discord.gg") || h.endsWith("discord.com") || h.endsWith("discordapp.com")) return "discord";
  if (h.endsWith("twitch.tv")) return "twitch";
  if (h.endsWith("instagram.com")) return "instagram";
  if (h.endsWith("github.com")) return "github";
  return null;
}

export function parseSocial(
  input: { url: string; type?: SocialType; name?: string; handle?: string },
): ParsedSocial {
  const u = toUrl(input.url);
  const type = input.type ?? (u ? detectType(u.hostname) : null);
  const parts = u ? u.pathname.split("/").filter(Boolean).map(decodeURIComponent) : [];

  let handle = "";
  let inviteCode = "";

  if (u && type) {
    const first = parts[0] ?? "";
    switch (type) {
      case "tiktok":
      case "instagram":
        handle = first ? (first.startsWith("@") ? first : `@${first}`) : "";
        break;
      case "youtube":
        if (u.hostname.includes("youtu.be")) handle = "";
        else if (first.startsWith("@")) handle = first;
        else if (["c", "user", "channel"].includes(first) && parts[1]) handle = parts[1];
        else handle = first;
        break;
      case "telegram":
        handle = first === "s" ? (parts[1] ? `@${parts[1]}` : "") : first ? `@${first.replace(/^@/, "")}` : "";
        break;
      case "twitch":
      case "github":
        handle = first;
        break;
      case "discord":
        if (u.hostname.endsWith("discord.gg")) inviteCode = first;
        else if (first === "invite") inviteCode = parts[1] ?? "";
        // ссылка на пользователя (discord.com/users/ID) — ник узнать нельзя, пишите handle вручную
        break;
    }
  }

  return {
    type,
    name: input.name || (type ? NAMES[type] : u?.hostname.replace(/^www\./, "") ?? input.url),
    handle: input.handle ?? handle,
    href: u ? u.toString() : input.url,
    inviteCode,
  };
}
