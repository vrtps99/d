import { useEffect } from "react";
import Background from "./Background";
import { profile, socials, projects, type Project, type SocialLink } from "./config";
import { parseSocial } from "./socials";
import { ArrowIcon, CreeperLogo, DiscordLogo, SocialIcon } from "./icons";
import { inviteUrl, useInvite } from "./useInvite";

const fmt = (n: number) => n.toLocaleString("en-US");

function ProjectCard({ p }: { p: Project }) {
  const { code, info, done } = useInvite(p.invite);

  const title = p.title || info?.name || code;
  const description = p.description || info?.description || "";
  const image = p.image || info?.icon || "";

  return (
    <a
      href={inviteUrl(p.invite)}
      target="_blank"
      rel="noreferrer"
      className="flex items-center gap-4 rounded-lg border border-white/10 bg-[#0d0d0d]/90 p-4 backdrop-blur transition hover:border-white/25 hover:bg-white/5"
    >
      {image ? (
        <img src={image} alt={title} className="h-14 w-14 shrink-0 rounded-xl object-cover" />
      ) : (
        <div
          className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: p.color }}
        >
          {p.icon === "discord" && <DiscordLogo className="h-9 w-9" />}
          {p.icon === "minecraft" && <CreeperLogo className="h-10 w-10" />}
          {p.icon === "letter" && <span className="text-2xl font-semibold">{title.charAt(0)}</span>}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className="text-base font-semibold">{title}</div>
        {description && <p className="line-clamp-2 text-sm leading-5 text-neutral-400">{description}</p>}
        {info && (info.online !== null || info.members !== null) && (
          <div className="mt-1.5 flex items-center gap-3 text-xs text-neutral-500">
            {info.online !== null && (
              <span className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                {fmt(info.online)} online
              </span>
            )}
            {info.members !== null && <span>{fmt(info.members)} members</span>}
          </div>
        )}
        {!done && <div className="mt-1.5 h-3 w-32 animate-pulse rounded bg-white/10" />}
      </div>
      <ArrowIcon className="h-3.5 w-3.5 shrink-0 text-neutral-500" />
    </a>
  );
}

function SocialCard({ s }: { s: SocialLink }) {
  const parsed = parseSocial(s);
  const { info } = useInvite(parsed.inviteCode);
  const handle = s.handle ?? (info?.name || parsed.handle);

  return (
    <a
      href={parsed.href}
      target="_blank"
      rel="noreferrer"
      className="flex h-[62px] min-w-0 items-center gap-2 rounded-lg border border-white/10 bg-[#0d0d0d]/90 px-3 backdrop-blur transition hover:border-white/25 hover:bg-white/5 sm:gap-3 sm:px-4"
    >
      {parsed.type ? (
        <SocialIcon type={parsed.type} className="h-5 w-5 shrink-0 text-neutral-200" />
      ) : (
        <ArrowIcon className="h-5 w-5 shrink-0 text-neutral-200" />
      )}
      <div className="min-w-0 leading-tight">
        <div className="text-[15px] font-medium">{parsed.name}</div>
        {handle && <div className="mt-0.5 truncate text-[13px] text-neutral-500">{handle}</div>}
      </div>
    </a>
  );
}

export default function App() {
  useEffect(() => {
    document.title = profile.pageTitle;
  }, []);

  return (
    <div className="relative min-h-screen bg-[#0a0a0a] px-4 py-16 font-sans text-white antialiased">
      {/* Задний фон */}
      <Background />

      <main className="relative mx-auto w-full max-w-[536px]">
        {/* Профиль */}
        <header className="flex flex-col items-center text-center">
          {profile.avatar ? (
            <img src={profile.avatar} alt={profile.nick} className="h-28 w-28 rounded-full object-cover" />
          ) : (
            <div className="flex h-28 w-28 items-center justify-center rounded-full bg-[#262626] text-5xl font-medium text-neutral-200">
              {profile.nick.charAt(0).toUpperCase()}
            </div>
          )}
          <h1 className="mt-9 text-[32px] font-semibold tracking-tight">{profile.nick}</h1>
          <p className="mt-4 max-w-[400px] text-[15px] leading-6 text-neutral-400">{profile.bio}</p>
        </header>

        {/* Соцсети */}
        <section className="mt-10 grid grid-cols-3 gap-2 sm:gap-3">
          {socials.map((s) => (
            <SocialCard key={s.url} s={s} />
          ))}
        </section>

        {/* Проекты */}
        <section className="mt-14">
          <h2 className="text-sm font-medium uppercase tracking-widest text-neutral-500">{profile.projectsTitle}</h2>
          <div className="mt-4 space-y-3">
            {projects.map((p) => (
              <ProjectCard key={p.invite} p={p} />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
