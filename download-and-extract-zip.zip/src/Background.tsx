import { profile } from "./config";

// Достаёт ID видео из ссылок YouTube (watch?v=, youtu.be/, embed/, shorts/)
function youtubeId(url: string): string | null {
  const m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/i);
  return m ? m[1] : null;
}

const isVideoFile = (url: string) => /\.(mp4|webm|ogv|mov)(\?.*)?$/i.test(url);

export default function Background() {
  const src = profile.background;
  if (!src) return null;

  const filters = [
    profile.backgroundBrightness !== 1 ? `brightness(${profile.backgroundBrightness})` : "",
    profile.backgroundBlur ? `blur(${profile.backgroundBlur}px)` : "",
  ]
    .filter(Boolean)
    .join(" ");
  const blurStyle = {
    filter: filters || undefined,
    transform: profile.backgroundBlur ? "scale(1.05)" : undefined,
  };

  const yt = youtubeId(src);
  let layer: React.ReactNode;

  // Обрезка кадра видео (доли от 0 до 1)
  const { left: cl, right: cr, top: ct, bottom: cb } = profile.videoCrop;
  // Соотношение сторон оставшейся области (кадр YouTube 16:9)
  const ratio = ((1 - cl - cr) * 16) / ((1 - ct - cb) * 9);

  if (yt) {
    const params = new URLSearchParams({
      autoplay: "1",
      mute: "1",
      controls: "0",
      loop: "1",
      playlist: yt,
      modestbranding: "1",
      playsinline: "1",
      disablekb: "1",
      rel: "0",
      iv_load_policy: "3",
      fs: "0",
    });
    layer = (
      <div className="fixed inset-0 overflow-hidden bg-black" style={blurStyle}>
        {/*
          Область видео после обрезки (в долях кадра). Всё, что вне неё, не видно:
          заголовок плеера YouTube сверху и иконки/панель по краям кадра.
          Область растягивается на весь экран как object-fit: cover.
        */}
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 overflow-hidden"
          style={{ width: `max(100vw, ${100 * ratio}vh)`, height: `max(100vh, ${100 / ratio}vw)` }}
        >
          <iframe
            title="background"
            src={`https://www.youtube-nocookie.com/embed/${yt}?${params.toString()}`}
            allow="autoplay; encrypted-media"
            referrerPolicy="strict-origin-when-cross-origin"
            tabIndex={-1}
            className="pointer-events-none absolute border-0"
            style={{
              width: `${100 / (1 - cl - cr)}%`,
              height: `${100 / (1 - ct - cb)}%`,
              left: `${-(cl / (1 - cl - cr)) * 100}%`,
              top: `${-(ct / (1 - ct - cb)) * 100}%`,
            }}
          />
        </div>
      </div>
    );
  } else if (isVideoFile(src)) {
    layer = (
      <video
        className="fixed inset-0 h-full w-full object-cover"
        style={blurStyle}
        src={src}
        autoPlay
        muted
        loop
        playsInline
      />
    );
  } else {
    layer = (
      <div
        className="fixed inset-0 bg-cover"
        style={{
          backgroundImage: `url("${src}")`,
          backgroundPosition: profile.backgroundPosition,
          ...blurStyle,
        }}
      />
    );
  }

  return (
    <>
      {layer}
      <div className="fixed inset-0 bg-black" style={{ opacity: profile.backgroundDim }} />
    </>
  );
}
