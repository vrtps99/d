// ============================================================
//  ВСЁ, ЧТО НУЖНО МЕНЯТЬ, НАХОДИТСЯ В ЭТОМ ФАЙЛЕ
// ============================================================



export type SocialType = "tiktok" | "youtube" | "telegram" | "discord" | "twitch" | "instagram" | "github";


export const profile = {
  // Ник (крупный заголовок)
  nick: "ponchess",
  // Аватарка: ссылка на картинку, например "https://site.com/me.png".
  // Если "" — будет показана первая буква ника.
  avatar: "https://i.pinimg.com/1200x/63/95/03/639503685cf25a18132552eb80ea4b1a.jpg",
  // Описание под ником
  bio: "watching stars",
  // Заголовок над списком проектов
  projectsTitle: "Projects",
  // Заголовок вкладки браузера
  pageTitle: "ponchess",


  // ЗАДНИЙ ФОН. Можно указать любое из:
  //   • картинку или гифку:  "https://site.com/bg.jpg" / "https://site.com/bg.gif"
  //   • видеофайл:           "https://site.com/bg.mp4" (или .webm)
  //   • ссылку на YouTube:   "https://www.youtube.com/watch?v=jCu02P5FqGo"
  //   • свой файл из src/assets (как сейчас)
  // Если "" — будет обычный тёмный фон.
  background: "https://v1.pinimg.com/videos/iht/expMp4/be/93/96/be939635cebba9fbece0f3cbce5f4ab1_720w.mp4",
  // Куда смещать картинку, если она не влезает в экран (например на телефоне). Фонарь справа — 70%.
  backgroundPosition: "center",
  // Затемнение фона от 0 (нет) до 1 (полностью чёрный). Чтобы текст читался.
  backgroundDim: 0.3,
  // Яркость фона: 1 — как есть, больше 1 — ярче (например 1.5 или 2), меньше 1 — темнее
  backgroundBrightness: 1,
  // Обрезка кадра YouTube-видео (доли от 0 до 1) — чтобы убрать лишнее по краям
  // (заголовок плеера, иконки и т.п.). 0.25 = отрезать 25% с этой стороны.
  videoCrop: { left: 0, right: 0, top: 0.08, bottom: 0.1 },
  // Размытие фона в пикселях (0 — без размытия)
  backgroundBlur: 0,
};


// Соцсети. Достаточно вставить ТОЛЬКО ссылку (url) — всё остальное определится само:
//   • иконка и название (TikTok, YouTube, Telegram, Discord, Twitch, Instagram, GitHub) — по домену ссылки
//   • ник под названием — из ссылки (https://tiktok.com/@abc → "@abc")
//   • ссылка на сервер Discord (discord.gg/код) — подтянет название сервера
// Если нужно переопределить — добавь необязательные поля name, handle или type.
// Пример: { url: "https://t.me/abc", handle: "мой канал" }
export type SocialLink = {
  url: string;
  type?: SocialType;
  name?: string;
  handle?: string;
};


export const socials: SocialLink[] = [
  { url: "https://www.tiktok.com/@_ponchess?" },
  { url: "www.youtube.com/@ponchessxd" },
  // Ссылка на профиль Discord (discord.com/users/ID) ник не раскрывает, поэтому handle пишем вручную.
  // Если вставить ссылку-приглашение на сервер (https://discord.gg/код) — ник подтянется сам.
  { url: "https://discord.com/users/785482379312496680", handle: "_ponchess" },
];


export type Project = {
  // Код или полная ссылка приглашения Discord: "minecraft" или "https://discord.gg/minecraft".
  // По нему автоматически подтягиваются название, описание, аватарка, онлайн и участники.
  invite: string;


  // Необязательно: если заполнить — перезапишет то, что пришло из Discord.
  // Оставь "" чтобы брать автоматически.
  title?: string;
  description?: string;
  image?: string;


  // Запасной вариант, пока грузится или если Discord не ответил
  icon: "discord" | "minecraft" | "letter";
  color: string;
};


export const projects: Project[] = [
  {
    invite: "https://discord.gg/qZydqbE6VC",
    title: "",
    description: "",
    image: "",
    icon: "discord",
    color: "#5865F2",
  },
  {
    invite: "https://discord.gg/XaNKZ66SDs",
    title: "",
    description: "",
    image: "",
    icon: "discord",
    color: "#5865F2",
  },
];

