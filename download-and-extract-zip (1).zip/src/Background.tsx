import { useEffect, useRef } from "react";
import { profile } from "./config";
import { ChessRain, ChessBoard, Synthwave, Fireflies, RainOverlay, SnowOverlay } from "./ExtraBackgrounds";

// Звёздное небо: мерцающие звёзды + редкие падающие
function StarField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    let w = 0, h = 0, raf = 0;
    type Star = { x: number; y: number; r: number; a: number; s: number; p: number };
    type Shoot = { x: number; y: number; vx: number; vy: number; life: number };
    let stars: Star[] = [];
    const shoots: Shoot[] = [];

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round((w * h) / 4500);
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.3 + 0.2,
        a: Math.random() * 0.6 + 0.3,
        s: Math.random() * 0.02 + 0.005,
        p: Math.random() * Math.PI * 2,
      }));
    };

    const frame = (t: number) => {
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#02030a");
      g.addColorStop(0.6, "#0a1024");
      g.addColorStop(1, "#1a1740");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      for (const st of stars) {
        const tw = 0.5 + 0.5 * Math.sin(t * st.s + st.p);
        ctx.globalAlpha = st.a * (0.3 + 0.7 * tw);
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
        ctx.fill();
      }

      if (Math.random() < 0.004 && shoots.length < 2) {
        shoots.push({ x: Math.random() * w * 0.8, y: Math.random() * h * 0.4, vx: 9 + Math.random() * 4, vy: 4 + Math.random() * 3, life: 1 });
      }
      for (let i = shoots.length - 1; i >= 0; i--) {
        const s = shoots[i];
        s.x += s.vx;
        s.y += s.vy;
        s.life -= 0.016;
        if (s.life <= 0) { shoots.splice(i, 1); continue; }
        const tg = ctx.createLinearGradient(s.x, s.y, s.x - s.vx * 9, s.y - s.vy * 9);
        tg.addColorStop(0, `rgba(255,255,255,${s.life})`);
        tg.addColorStop(1, "rgba(255,255,255,0)");
        ctx.globalAlpha = 1;
        ctx.strokeStyle = tg;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x - s.vx * 9, s.y - s.vy * 9);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(frame);
    };

    resize();
    window.addEventListener("resize", resize);
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={ref} className="fixed inset-0 h-full w-full" />;
}

// Северное сияние: плавно движущиеся цветные пятна
function Aurora() {
  return (
    <div className="fixed inset-0 overflow-hidden bg-[#05060f]">
      <style>{`
        @keyframes aur1 { 0%,100% { transform: translate(-10%,0) scale(1);} 50% { transform: translate(15%,10%) scale(1.25);} }
        @keyframes aur2 { 0%,100% { transform: translate(10%,5%) scale(1.2);} 50% { transform: translate(-15%,-5%) scale(1);} }
        @keyframes aur3 { 0%,100% { transform: translate(0,10%) scale(1);} 50% { transform: translate(10%,-10%) scale(1.3);} }
      `}</style>
      <div className="absolute -left-1/4 -top-1/4 h-[70vh] w-[70vw] rounded-full bg-emerald-500/40 blur-[120px]" style={{ animation: "aur1 18s ease-in-out infinite" }} />
      <div className="absolute -right-1/4 top-0 h-[60vh] w-[60vw] rounded-full bg-violet-600/40 blur-[120px]" style={{ animation: "aur2 22s ease-in-out infinite" }} />
      <div className="absolute -bottom-1/4 left-1/4 h-[60vh] w-[60vw] rounded-full bg-sky-500/30 blur-[120px]" style={{ animation: "aur3 26s ease-in-out infinite" }} />
    </div>
  );
}

// Достаёт ID видео из ссылок YouTube (watch?v=, youtu.be/, embed/, shorts/)
function youtubeId(url: string): string | null {
  const m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/i);
  return m ? m[1] : null;
}

const isVideoFile = (url: string) => /\.(mp4|webm|ogv|mov)(\?.*)?$/i.test(url);

export default function Background() {
  const src = profile.background;
  if (!src) return null;
  if (src === "rain")
    return (
      <>
        <div className="fixed inset-0 bg-gradient-to-b from-[#05070d] via-[#0a0f1a] to-[#121a2b]" />
        <RainOverlay />
      </>
    );
  if (src === "stars") return <StarField />;
  if (src === "aurora") return <Aurora />;
  if (src === "chess-rain") return <ChessRain />;
  if (src === "chess-board") return <ChessBoard />;
  if (src === "synthwave") return <Synthwave />;
  if (src === "fireflies") return <Fireflies />;

  const filters = [
    profile.backgroundBrightness !== 1 ? `brightness(${profile.backgroundBrightness})` : "",
    profile.backgroundBlur ? `blur(${profile.backgroundBlur}px)` : "",
  ]
    .filter(Boolean)
    .join(" ");
  const blurStyle = {
    filter: filters || undefined,
    transform: profile.backgroundBlur ? "scale(1.05)" : undefined,
  };

  const yt = youtubeId(src);
  let layer: React.ReactNode;

  // Обрезка кадра видео (доли от 0 до 1)
  const { left: cl, right: cr, top: ct, bottom: cb } = profile.videoCrop;
  // Соотношение сторон оставшейся области (кадр YouTube 16:9)
  const ratio = ((1 - cl - cr) * 16) / ((1 - ct - cb) * 9);

  if (yt) {
    const params = new URLSearchParams({
      autoplay: "1",
      mute: "1",
      controls: "0",
      loop: "1",
      playlist: yt,
      modestbranding: "1",
      playsinline: "1",
      disablekb: "1",
      rel: "0",
      iv_load_policy: "3",
      fs: "0",
    });
    layer = (
      <div className="fixed inset-0 overflow-hidden bg-black" style={blurStyle}>
        {/*
          Область видео после обрезки (в долях кадра). Всё, что вне неё, не видно:
          заголовок плеера YouTube сверху и иконки/панель по краям кадра.
          Область растягивается на весь экран как object-fit: cover.
        */}
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 overflow-hidden"
          style={{ width: `max(100vw, ${100 * ratio}vh)`, height: `max(100vh, ${100 / ratio}vw)` }}
        >
          <iframe
            title="background"
            src={`https://www.youtube-nocookie.com/embed/${yt}?${params.toString()}`}
            allow="autoplay; encrypted-media"
            referrerPolicy="strict-origin-when-cross-origin"
            tabIndex={-1}
            className="pointer-events-none absolute border-0"
            style={{
              width: `${100 / (1 - cl - cr)}%`,
              height: `${100 / (1 - ct - cb)}%`,
              left: `${-(cl / (1 - cl - cr)) * 100}%`,
              top: `${-(ct / (1 - ct - cb)) * 100}%`,
            }}
          />
        </div>
      </div>
    );
  } else if (isVideoFile(src)) {
    layer = (
      <video
        className="fixed inset-0 h-full w-full object-cover"
        style={blurStyle}
        src={src}
        autoPlay
        muted
        loop
        playsInline
      />
    );
  } else {
    layer = (
      <div
        className="fixed inset-0 bg-cover"
        style={{
          backgroundImage: `url("${src}")`,
          backgroundPosition: profile.backgroundPosition,
          ...blurStyle,
        }}
      />
    );
  }

  return (
    <>
      {layer}
      <div className="fixed inset-0 bg-black" style={{ opacity: profile.backgroundDim }} />
      {profile.backgroundRain && <RainOverlay />}
      {profile.backgroundSnow && <SnowOverlay src={profile.backgroundSnow} />}
    </>
  );
}
