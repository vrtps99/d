import { useEffect, useRef } from "react";

// Общий хук для canvas-анимаций
function useCanvas(setup: (ctx: CanvasRenderingContext2D, w: number, h: number) => (t: number) => void) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    let draw: (t: number) => void = () => {};
    const init = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = window.innerWidth;
      const h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw = setup(ctx, w, h);
    };
    const loop = (t: number) => {
      draw(t);
      raf = requestAnimationFrame(loop);
    };
    init();
    window.addEventListener("resize", init);
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", init);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return ref;
}

// Дождь из шахматных фигур (как «Матрица»)
export function ChessRain() {
  const ref = useCanvas((ctx, w, h) => {
    const glyphs = "♔♕♖♗♘♙♚♛♜♝♞♟";
    const size = 22;
    const cols = Math.ceil(w / size);
    const drops = Array.from({ length: cols }, () => Math.random() * -h / size);
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, w, h);
    return () => {
      ctx.fillStyle = "rgba(0,0,0,0.12)";
      ctx.fillRect(0, 0, w, h);
      ctx.font = `${size}px serif`;
      for (let i = 0; i < cols; i++) {
        const ch = glyphs[Math.floor(Math.random() * glyphs.length)];
        const y = drops[i] * size;
        ctx.fillStyle = "rgba(220,255,230,0.95)";
        ctx.fillText(ch, i * size, y);
        ctx.fillStyle = "rgba(34,197,94,0.55)";
        ctx.fillText(ch, i * size, y - size);
        if (y > h && Math.random() > 0.975) drops[i] = 0;
        drops[i] += 0.35;
      }
    };
  });
  return <canvas ref={ref} className="fixed inset-0 h-full w-full bg-black" />;
}

// Бесконечный шахматный пол в перспективе
export function ChessBoard() {
  return (
    <div className="fixed inset-0 overflow-hidden bg-black" style={{ perspective: "500px" }}>
      <style>{`@keyframes boardmove { from { background-position: 0 0; } to { background-position: 0 160px; } }`}</style>
      <div
        className="absolute left-1/2 top-[38%] h-[200vh] w-[300vw] -translate-x-1/2 origin-top"
        style={{
          transform: "translateX(-50%) rotateX(68deg)",
          backgroundImage:
            "conic-gradient(#1c1c22 25%, #08080b 0 50%, #1c1c22 0 75%, #08080b 0)",
          backgroundSize: "160px 160px",
          animation: "boardmove 4s linear infinite",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black via-black/60 to-transparent" style={{ height: "55%" }} />
      <div className="absolute inset-x-0 top-[34%] h-24 bg-gradient-to-b from-transparent via-white/10 to-transparent blur-2xl" />
    </div>
  );
}

// Синтвейв: солнце и неоновая сетка
export function Synthwave() {
  return (
    <div className="fixed inset-0 overflow-hidden bg-gradient-to-b from-[#0b0220] via-[#2a0845] to-[#6a1b6e]" style={{ perspective: "400px" }}>
      <style>{`@keyframes gridmove { from { background-position: 0 0; } to { background-position: 0 60px; } }`}</style>
      <div
        className="absolute left-1/2 top-[42%] h-[60vh] w-[60vh] max-w-[80vw] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{ background: "linear-gradient(#ffd24a, #ff3d81 60%, #b100ff)", boxShadow: "0 0 80px #ff3d81aa" }}
      />
      <div className="absolute inset-x-0 top-[42%] bottom-0 bg-[#0b0220]" />
      <div
        className="absolute left-1/2 top-[42%] h-[200vh] w-[300vw] -translate-x-1/2 origin-top"
        style={{
          transform: "translateX(-50%) rotateX(72deg)",
          backgroundImage:
            "linear-gradient(#ff3d81 2px, transparent 2px), linear-gradient(90deg, #ff3d81 2px, transparent 2px)",
          backgroundSize: "60px 60px",
          animation: "gridmove 1.2s linear infinite",
          opacity: 0.7,
        }}
      />
      <div className="absolute inset-x-0 top-[42%] h-40 bg-gradient-to-b from-[#0b0220] to-transparent" />
    </div>
  );
}

// Светлячки
export function Fireflies() {
  const ref = useCanvas((ctx, w, h) => {
    const n = Math.round((w * h) / 22000) + 12;
    const flies = Array.from({ length: n }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 2 + 1,
      a: Math.random() * Math.PI * 2,
      sp: Math.random() * 0.3 + 0.1,
      p: Math.random() * 6.28,
    }));
    return (t) => {
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#030806");
      g.addColorStop(1, "#0b1a12");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      for (const f of flies) {
        f.a += (Math.random() - 0.5) * 0.15;
        f.x += Math.cos(f.a) * f.sp;
        f.y += Math.sin(f.a) * f.sp;
        if (f.x < -10) f.x = w + 10;
        if (f.x > w + 10) f.x = -10;
        if (f.y < -10) f.y = h + 10;
        if (f.y > h + 10) f.y = -10;
        const glow = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t / 600 + f.p));
        const rad = f.r * 9;
        const gr = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, rad);
        gr.addColorStop(0, `rgba(250,240,140,${glow})`);
        gr.addColorStop(1, "rgba(250,240,140,0)");
        ctx.fillStyle = gr;
        ctx.fillRect(f.x - rad, f.y - rad, rad * 2, rad * 2);
      }
    };
  });
  return <canvas ref={ref} className="fixed inset-0 h-full w-full bg-black" />;
}

// Капли дождя поверх фона (прозрачный слой)
export function RainOverlay() {
  const ref = useCanvas((ctx, w, h) => {
    const n = Math.round(w / 6);
    const drops = Array.from({ length: n }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      l: Math.random() * 18 + 10,
      v: Math.random() * 10 + 14,
      a: Math.random() * 0.25 + 0.1,
    }));
    return () => {
      ctx.clearRect(0, 0, w, h);
      ctx.lineWidth = 1;
      for (const d of drops) {
        ctx.strokeStyle = `rgba(190,210,255,${d.a})`;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - d.l * 0.15, d.y + d.l);
        ctx.stroke();
        d.y += d.v;
        d.x -= d.v * 0.15;
        if (d.y > h) {
          d.y = -d.l;
          d.x = Math.random() * (w + 100);
        }
      }
    };
  });
  return <canvas ref={ref} className="pointer-events-none fixed inset-0 h-full w-full" />;
}

// Падающий снег: видео с белыми снежинками на чёрном, накладывается через screen (чёрное становится прозрачным)
export function SnowOverlay({ src }: { src: string }) {
  return (
    <video
      className="pointer-events-none fixed inset-0 h-full w-full object-cover mix-blend-screen"
      src={src}
      autoPlay
      muted
      loop
      playsInline
    />
  );
}
